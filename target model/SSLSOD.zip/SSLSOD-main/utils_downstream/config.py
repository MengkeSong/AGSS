# coding: utf-8
import os

dutrgbd_root_test = ''
njud_root_test = ''
nlpr_root_test = ''
stere_root_test =''
sip_root_test = ''
rgbd135_root_test = ''
ssd_root_test = ''
lfsd_root_test = ''


dutrgbd = os.path.join(dutrgbd_root_test)
njud = os.path.join(njud_root_test)
nlpr = os.path.join(nlpr_root_test)
stere = os.path.join(stere_root_test)
sip = os.path.join(sip_root_test)
rgbd135 = os.path.join(rgbd135_root_test)
ssd = os.path.join(ssd_root_test)
lfsd = os.path.join(lfsd_root_test)


SSLSOD = '' # model

RGBD_SOD_Models = {'SSLSOD':SSLSOD}
